﻿//Archivo de JS para el Index.html

//Boton de contacto para mandar hacia el formulario.


function irContacto() {

   $("html, body").animate({ scrollTop: $(document).height() }, "slow");
}