/*
	* MQTT-WebClient example for Web-IO 4.0
*/
var hostname = "test.mosquitto.org";
var port = 8081;
var clientId = "test";
clientId += new Date().getUTCMilliseconds();;
var subscription = "robot/modo";
var username = "webclient";
var password = "Super$icher123";
mqttClient = new Paho.MQTT.Client(hostname, port, clientId);
mqttClient.onMessageArrived = MessageArrived;
mqttClient.onConnectionLost = ConnectionLost;
Connect();

/*Initiates a connection to the MQTT broker*/
function Connect(){
	mqttClient.connect({
	onSuccess: Connected,
	onFailure: ConnectionFailed,
	});
}

/*Callback for successful MQTT connection */
function Connected() {
	console.log("Conectado a MQTT");
	mqttClient.subscribe(subscription);
	//mqttClient.publish("robot/modo", "0x006");
}

/*Callback for failed connection*/
function ConnectionFailed(res) {
	console.log("Conexion MQTT fallida:" + res.errorMessage);
}

/*Callback for lost connection*/
function ConnectionLost(res) {
	if (res.errorCode !== 0) {
		console.log("Connexion Perdida:" + res.errorMessage);
		Connect();
	}
}

/*Callback for incoming message processing */
function MessageArrived(message) {
	console.log(message.destinationName +" : " + message.payloadString);
	switch(message.payloadString){
		case "0x005":
			displayClass = "on";
			console.log("HA LLEGADO")
			break;
		case "OFF":
			displayClass = "off";
			break;
		default:
			displayClass = "unknown";
	}
	var topic = message.destinationName.split("/");
	if (topic.length == 3){
		var ioname = topic[1];
		UpdateElement(ioname, displayClass);
	}
}